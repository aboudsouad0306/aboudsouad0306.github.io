<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Finddz-accueil</title>
<link href="css.css" rel="stylesheet" type="text/css" />
<link href="css/boutons.css" rel="stylesheet" type="text/css" />


</head>

<body>
<div class="top">

<!--<td>-->
<img src="imgs/mini-logo.png" />
<!--</td>-->

  <div id="acces">
  <form id="form1" name="form1" method="post" action="acces_memebre.php">
  <br/><br/>
    Email:<input type="text" name="email" id="email" />
   Mot de passe:<input type="password" name="mdp" id="mdp" />
   <input type="submit" name="button" id="button" value="GO!" />
   </form>
   
  </div>
<ul id="lien">
 <li>
   <a href="inscription.php">>Inscription</a>
   </li>
  
   <li>
   <a href="lostmdp.php">>Mot de passe oublié?</a>
   </li>
  
   </ul> 
</div>
<div class="container">

  <div class="navigation">

  <a href="index.php" class="nav">Accueil</a>
  <a href="annuaire.php" class="nav">Annuaire</a>
  <a href="annonces.php" class="nav">Petites annonces</a>
  <a href="actualite.php" class="nav">Actualités</a>
  <a href="inscription.php" class="nav">Inscription</a>

</div>
  <div class="header">
  <img src="imgs/logo_web.png" width="300" height="177" class="logo"/>
   </div>
  <div class="search">
  <center> 
  <form action="search_engine.php" method="post">
  <table width="700" border="0">
  <tr>
    <td>Quoi?</td>
    <td><input name="search" type="text" size="50" id="chp"/></td>
    <td>Ou?</td>
    <td>
    <select name="wilaya" id="select">
    <?php
	//cette portion de code va nous permettre de recuperer la liste des wilayas algeriennes lol!
	include("wiliste.php");
	?>
    </select>
    </td>
    <td><input name="" type="submit" value="Trouver!" class="searchbtn"/></td>
  </tr>
</table>
</form>
</center>  
  </div>
  <div class="add">
  <div class="hour">
  <?php
    /*afficher la date et l'heure courante!!
  $date_du_jour = date ("d-m-Y");
  $heure_courante = date ("H:i");
   echo 'Nous sommes le : ';
   echo $date_du_jour;
   echo ' Et il est : ';
   echo $heure_courante;*/
   ?>
  </div>
  <center>
	<img src="imgs/ajouter.jpg" width="270" height="360"/>
    <a href="ajouter.php" class="adbtn">AJOUTER VOTRE ENTREPRISE!</a>
	<!--zone pour la news letter-->
	<br/>
	</center>
</div>

  <div class="horbar">

  <a href="#" class="btn">Par secteurs d'activité</a>
  <a href="#" class="btn">Par localisation géographique</a>
    <?php
    //afficher les different secteur d'activités!!
    include("cat.php");
   ?>
    <p></p>
   </div>
   <div class="meteo">
   <div id="methead">
    Météo pour les 3 prochains jours<br/> <br/> 
    <select name="wilaya" id="select">
    <?php
	//cette portion de code va nous permettre de recuperer la liste des wilayas algeriennes lol!
	include("wiliste.php");
	?>
    </select>
    </div>
   <!-- ce code a été copié du site http://www.my-meteo.fr/meteo+webmaster.html-->
  
    <div id="widget_461183aafc9fa90c5a2898b3c3b1931e">
    <a href="http://www.my-meteo.fr/previsions+meteo+algerie/alger.html" title="M&eacute;t&eacute;o Alger">M&eacute;t&eacute;o Alger</a>
    <script type="text/javascript" src="http://www.my-meteo.fr/meteo+webmaster/widget/js.php?ville=1&amp;format=petit-horizontal&amp;nb_jours=3&amp;icones&amp;vent&amp;c1=414141&amp;c2=21a2f3&amp;c3=d4d4d4&amp;c4=FFF&amp;id=461183aafc9fa90c5a2898b3c3b1931e"></script>
    </div>

   </div>
    <div class="home">
<?php
//recuperer les dernieres actualités + affichage
$sql=mysql_query("SELECT * FROM actualite ORDER BY date LIMIT 1");
//affichage
while($resultat=mysql_fetch_array($sql))
{


?>
<div class="news">>> à la une
   <a href="actualite.php" class="toute"><img src="imgs/bttn.png"/></a>
</div>
  <div id="zonea">
 <h3>à la une</h3>
 
 <?php echo '<h1>'.$resultat["titre"].'</h1>'; ?>
 <?php echo '<p>'.$resultat["article"].'<br/>'; ?>
 <a href="actu_plus.php?id=<?php echo $resultat["id"];?>" class="suite">+ lire la suite</a><br/><br/>
 
 </p>
 
  </div>
<?php
}
?>
  <div id="zoneb">
   <h3>la zone B</h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam Identifiant libero sem. Aenean Pellentesque faucibus augue, id euismod elit vestibulum UE. Ut nec justo felis.
 Phasellus eu Velit nec ante auctor Mattis.
 <br/>
 <a href="#" class="suite">+ lire la suite</a>
 </p>
  </div>
  <div id="zonec">
   <h3>la zone C</h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam Identifiant libero sem. Aenean Pellentesque faucibus augue,     id euismod elit vestibulum UE. Ut nec justo felis.
     Phasellus eu Velit nec ante auctor Mattis.
 <br/>
 <a href="#" class="suite">+ lire la suite</a>
 </p>
  </div>
 <!--fin de la div home-->     
</div>
 <div class="content">
    <p></p>
    <!-- fin .content -->
    </div>
    
  <div class="profooter">
    <table width="960"> 
	<tr>
	
	<td width="320">
	<ul>
	<ul id="footmenu">
	<li><a href="#">accueil</a></li>
	<li><a href="#">qui sommes nous?</a></li>
	<li><a href="#">service client</a></li>
	<li><a href="#">nous contacter</a></li>
	<li><a href="#">informations juridiques</a></li>
	</td>
	<td>
		
	</td>
	<td width="320">
	<div id="letter">
	<?php
    //verifier si il existe des valeurs dans le champ de l'email!!
	if(isset ($_POST["email"]) && ($_POST["email"]!=NULL))
	{
	$email=$_POST["email"];
	//introduire l'email a la base de données
	$sql="INSERT INTO `its`.`email` (`id`, `email`) VALUES (NULL, '$email');"; 
	
    mysql_query($sql); 
	//message de confirmation
	echo'Votre adresse E-mail a été enregistrer avec succes!';
	}
    else{
   ?>
	Abonnez-vous à notre newsletter<br/><br/>
    <form name="input" action="" method="POST">
    <input type="text" name="email" class="email">
    <input type="submit" name="button" id="button" class="okbut" value="OK" />
    </form>
	<?php
   }
   ?>	
	</div>
	</td>
	</tr> 
	</table>
    <p></p>
    <!-- fin .profooter -->
    </div>
   
  <div class="footer">
    <p><a href="http://www.infotoolssolutions.dz">Powred by Info Tools Solutions 2013</a></p>
    <!-- end .footer -->
  </div>
  <!-- end .container -->
</div>
</body>
</html>
