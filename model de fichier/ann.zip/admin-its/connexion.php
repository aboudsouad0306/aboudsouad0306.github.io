<?php

$labase="its";

$chemin=mysql_connect("localhost","root","")or die("Impossible de se connecter:".mysql_error());

mysql_select_db($labase,$chemin);

//affichage des caracteres en UTF 8

mysql_query("SET NAMES 'utf8'");

?>