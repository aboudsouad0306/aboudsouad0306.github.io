<?php
//etablir la connexion a la base de donn�es
include("connexion.php");
//requette pour recuperer la liste des utilisateurs
$sql=mysql_query("SELECT * FROM actualite");
// affichage des resultats dans un tableau

while($resultat=mysql_fetch_array($sql))
{
echo '<h4>'.$resultat["titre"].'</h4>';
echo '<p>'.$resultat["article"].'</p>';
echo '<p>'.$resultat["date"].'</p>';
}
	
     ?>