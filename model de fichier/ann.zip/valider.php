<?php
//ce fichier va nous permettre de recuperer les données saisies par un utilisateur puis les sauvgardé dans la base de données

if( isset($_POST["secteur"]) and isset($_POST["nom"]) and isset($_POST["raison"]) and isset($_POST["description"]) and isset($_POST["tel"]) and isset($_POST["fax"]) and isset($_POST["adresse"]) and isset($_POST["region"]))
{
//recuperer les données saisies dans le formulaire et les transformer en variables

$secteur=addslashes($_POST["secteur"]);
$nom=addslashes($_POST["nom"]);
$raison=addslashes($_POST["raison"]);
$description=addslashes($_POST["description"]);
$tel=addslashes($_POST["tel"]);
$fax=addslashes($_POST["fax"]);
$adresse=addslashes($_POST["adresse"]);
$region=addslashes($_POST["region"]);
// fin de la recolte!!



//etablir la connexion a la base de données
include("connexion.php");

//recuperer l'identifiant du secteur d'activité

$sql=mysql_query("SELECT* FROM categorie WHERE nom='$secteur'");
//recuperer le id:
while($res=mysql_fetch_assoc($sql)){

$idcat=$res["id"];
}

//recuperer l'identifiant de laregion "Wilaya" 

$sql=mysql_query("SELECT* FROM wilaya WHERE wilaya='$region'");
//recuperer le id:
while($res=mysql_fetch_assoc($sql)){

$idw=$res["id"];
}

// la ou commence les requettes d'insertion lol!!

// insertion de données ...........

$sql = "INSERT INTO `its`.`entreprise` (`id`, `nom`, `raisonsocial`,`description` , `adresse`, `Tel`, `Fax`, `idcat`, `idwilaya`)
VALUES (NULL, '$nom', '$raison', '$description', '$adresse', '$tel', '$fax', '$idcat', '$idw');"; 

mysql_query($sql); 

}//fin de la condition if du depart !!

// on insère les informations du formulaire dans la table
    //mysql_query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());

    // on affiche le résultat pour le visiteur
    echo 'Vos infos on été ajoutées.';
	echo stripslashes($secteur).'<br/>';
	echo stripslashes($nom).'<br/>';
	echo stripslashes($raison).'<br/>';
	echo stripslashes($tel).'<br/>';
	echo stripslashes($fax).'<br/>';
	echo stripslashes($adresse).'<br/>';
	echo stripslashes($region).'<br/>';
	
	echo'<a href="">imprimmer le message de confirmation!</a>';
	

    //mysql_close();  // on ferme la connexion
   // } 
 



?>