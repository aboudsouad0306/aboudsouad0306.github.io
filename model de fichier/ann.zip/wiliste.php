<?php
//etablir la connexion a la base de données

include("connexion.php");

// lancer une requette sur la table wilaya de la base de données!!

$sql=mysql_query("SELECT * FROM wilaya ORDER BY id");

// afficher les resultats de la requette !!

//boucle while tant que 

while($resultat=mysql_fetch_assoc($sql))
{
	echo '<option>'.$resultat["wilaya"].'</option>';
	}


?>
<!--<option value="1">Ou?</option>-->