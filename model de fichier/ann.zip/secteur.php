<?php
//etablir la connexion a la base de donées
include("connexion.php");
$sql=mysql_query("SELECT * FROM categorie");
// afficher les resultats de la recherche

//echo'<SELECT name="activite">';
while($resultat=mysql_fetch_assoc($sql))
{
echo '<option>'.$resultat["nom"].'</option>';
} 
//echo'</SELECT>';



?>